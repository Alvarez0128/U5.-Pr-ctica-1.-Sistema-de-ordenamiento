/**
 * 
 * @author C3S4R_4LV
 */
public class Arreglo {
    public int[] generarArreglo(int tam){
        int[] arreglo=new int[tam];
        for(int i=0;i<arreglo.length;i++){
            do{
                arreglo[i]=(int) (Math.random() * (100)+1);
            }while(arreglo[i]==0);
        }
        return arreglo;
    }
    
    public int[] OrdenarXBurbuja(int [] A){
        int arre[] = A;
        int temp;
        
        for(int i=1;i<arre.length;i++){
            for(int j=0; j<arre.length-i;j++){
                if(arre[j]>arre[j+1]){
                    temp=arre[j];
                    arre[j]=arre[j+1];
                    arre[j+1]=temp;
                }
            }
        }        
        return arre;
    }
    
    public int [] OrdenarXQuicksort(int []A){
        return Quicksort(A,0,A.length-1);
    }
    public int [] Quicksort(int arreglo[],int izq, int der){
        int i=izq,d=der;
        if(izq>=der){
            return arreglo;
        }
        if(izq!=der){
            int piv=izq,aux;
            while(izq!=der){
                while(arreglo[der]>=arreglo[piv]&& izq<der){
                    der--;
                }
                while(arreglo[izq]<arreglo[piv]&&izq<der){
                    izq++;
                }
                if(der!=izq){
                    aux=arreglo[der];
                    arreglo[der]=arreglo[izq];
                    arreglo[izq]=aux;
                }
                if(izq==der){
                    Quicksort(arreglo,i,izq-1);
                    Quicksort(arreglo,izq+1,d);
                }
            }
        }else{
            return arreglo;
        }
        return arreglo;
    }
    
    public void OrdenarXShellSort(int[]A){
        int salto, aux, i;
        boolean cambios;
  
        for (salto = A.length / 2; salto != 0; salto /= 2) {
            cambios = true;
            while (cambios) {                                       
                cambios = false;
                for (i = salto; i < A.length; i++)   
                {
                    if (A[i - salto] > A[i]) {       
                        aux = A[i];                 
                        A[i] = A[i - salto];
                        A[i - salto] = aux;
                        cambios = true;                                                 
                    }
                }
            }
        }
    }
    
    public void OrdenarXRadix(int [] A){
        int[][] np= new int [A.length][2];
        int[]q=new int [0x100];
        int i,j,l,f=0;
        for(int k=0;k<4;k++){
            for(i=0;i<(np.length-1);i++){
                np[i][1]=i+1;
            }
            np[i][1]=-1;
            for(i=0;i<q.length;i++){
                q[i]=-1;
            }
            for(f=i=0;i<A.length;i++){
                j=((0xFF<<(k<<3))&A[i])>>(k<<3);
                if(q[j]==-1){
                    l=q[j]=f;
                }else{
                    l=q[j];
                    while(np[l][1]!=-1){
                        l=np[l][1];
                    }
                    np[l][1]=f;
                    l=np[l][1]=f;
                }
                f=np[f][1];
                np[l][0]=A[i];
                np[l][1]=-1;
            }
            for(l=q[i=j=0];i<0x100;i++){
                for(l=q[i];l!=-1;l=np[l][1]){
                    A[j++]=np[l][0];
                }
            }
        }
    }
}
